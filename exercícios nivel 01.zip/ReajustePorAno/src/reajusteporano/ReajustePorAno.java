package reajusteporano;

import java.util.Scanner;

public class ReajustePorAno {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        System.out.println("Informe os anos trabalhados");
        int AnoWork = leia.nextInt();
        System.out.println("Informe o seu salario");
        double Salario = leia.nextDouble();
        double Reajuste = 0;
        if(AnoWork <= 2){
            Reajuste = Salario * 0.05;
        }
        else if(AnoWork <= 5){
            Reajuste = Salario * 0.10;
        }
        else if(AnoWork > 5){
            Reajuste = Salario * 0.15;
        }
        double aumento = Salario + Reajuste;
        System.out.println("O seu salario é " + aumento);
        System.out.println("O reajuste é de " + Reajuste);
    }
    
}
