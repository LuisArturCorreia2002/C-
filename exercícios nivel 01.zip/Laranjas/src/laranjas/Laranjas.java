package laranjas;

import java.util.Scanner;


public class Laranjas {


    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int QuantiaLaranjas = 0;
        double defaultPrices = 1.10;
        boolean desconto = false;
        System.out.println("Informe quantidade de laranjas");
        QuantiaLaranjas = leia.nextInt();
        if(QuantiaLaranjas >= 12){
            defaultPrices = 0.75;
            desconto = true;
        }
        double valorTotal = QuantiaLaranjas * defaultPrices;
        System.out.println("Você comprou " + QuantiaLaranjas + " de laranjas no valor de R$" + valorTotal);
        if(desconto == true){
            System.out.println("Como você comprou mais ou 12 laranjas, o preço da laranja ficou por R$0.75 centavos");
        }
        else{
            System.out.println("Como você comprou menos de 12 laranjas, o preço da laranja ficou por R$1.10 reais");
        }
        
    }
    
}
