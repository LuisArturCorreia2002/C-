package javaapplication1;

import java.util.Scanner;

public class JavaApplication1 {

    public static void main(String[] args) {
       Scanner leia = new Scanner(System.in);
       double salário = 1000;
       double reajuste = 0.15;
       double total = 0;
       total = reajuste * salário;
       System.out.println("Seu salário ajustado seria: " + total);
    }
    
}
