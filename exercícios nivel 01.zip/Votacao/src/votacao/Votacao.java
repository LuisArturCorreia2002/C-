package votacao;

import java.util.Scanner;

public class Votacao {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        int anoAtual = 2019;
        int mesAtual = 4;
        int mes = 0;
        System.out.println("Informe o ano que você nasceu");
        int ano = leia.nextInt();
        System.out.println("Informe o mês que você nasceu");
        mes = leia.nextInt();
        int idade = anoAtual - ano;
        if(mes >= mesAtual){
            idade -= 1;
        }
        else{
            idade = idade;
        }
        System.out.println("Você tem " + idade + " anos de idade");
        if(idade >= 16){
            System.out.println("Você pode votar");
        }
        else{
            System.out.println("Você não pode votar");
        }
    }
    
}
