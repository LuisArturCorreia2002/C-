package ordemcrescente;

import java.util.Scanner;

public class OrdemCrescente {

    public static void main(String[] args) {
      Scanner leia = new Scanner(System.in);
       System.out.println("Primeiro Valor: ");
       double primeiro = leia.nextDouble();
       System.out.println("Segunda valor: ");
       double segundo = leia.nextDouble();
       if(primeiro <segundo){
           System.out.println("O menor é:" + primeiro);
       }
       else{
        System.out.println("O menor é:" + segundo);
        }
    }