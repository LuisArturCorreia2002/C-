package raiz;

import java.util.Scanner;


public class Raiz {


    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        
        double a;
        System.out.println("Informe o valoir de A: ");
        a = leia.nextDouble();
        
        double b;
        System.out.println("Informe o valoir de B: ");
        b = leia.nextDouble();
        
        double c;
        System.out.println("Informe o valoir de C: ");
        c = leia.nextDouble();
        
        double delta = (b*b) -4*a*c;
        
        double x1 = (-b + Math.sqrt(delta)) /2*a;
        System.out.println("O valor de x1 é: " + x1);
        
        double x2 = (-b - Math.sqrt(delta)) /2*a;
        System.out.println("O valor de x2 é: " + x2);  
    }
    
}
