package horastrabalhada;

import java.util.Scanner;

public class HorasTrabalhada {
    public static void main(String[] args) {
     Scanner leia = new Scanner (System.in);
      System.out.println("Informe horas semanais trabalhadas: ");
      double trabalhadas = leia.nextDouble();
      double calc = trabalhadas * 4;
      System.out.println("Você trabalhou "+calc+" horas");
      System.out.println("informe salario: ");
      double salario = leia.nextDouble();
      double valorHora = salario/(trabalhadas * 4);
      System.out.println("Salario por hora: "+valorHora+" R$");
      double extra = 50.0 / 100;
      double extras = valorHora + extra;
      System.out.println("valor de uma hora extra: "+extras+" R$");
      System.out.println("Horas extras trabalhadas: ");
      double horas = leia.nextDouble();
      double horaMais = horas * extras;
      System.out.println("valor das horas extras: "+horaMais+ "R$");
      double salarioMaisExtra = salario + horaMais;
      System.out.println("Seu salario com horas extras equivale a: " +salarioMaisExtra +" R$");
    }
    
}
