package positivonegativo;

import java.util.Scanner;

public class PositivoNegativo {

    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        System.out.println("Informe um número:");
        int num = leia.nextInt();
        if(num < 0){
            System.out.println("O número " + num + " é negativo");
        }
        else{
            System.out.println("O número " + num + " é positivo");
        }
    }
    
}
