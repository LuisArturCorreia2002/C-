package distancenumber;

import java.util.Random;
import java.util.Scanner;

public class DistanceNumber {

    public static void main(String[] args) {
        Random gerador = new Random();
        Scanner leia = new Scanner(System.in);
        int numberRandom = gerador.nextInt(101);
        System.out.println("Informe um número");
        int numberDigitado = leia.nextInt();
        int resposta = 0;
        if(numberDigitado < numberRandom){
            resposta = numberRandom - numberDigitado;
        }
        else{
            resposta = numberDigitado - numberRandom;
        }
        System.out.println("\n O número chave é : " + numberRandom + "\n Número digitado " + numberDigitado + "\n Falta " + resposta + " para " + numberRandom);
    }
    
}
