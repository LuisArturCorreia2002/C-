package calculadora;

import operacao.OperacoesBasicas;

public class Calculadora {

    public static void main(String[] args) {
        
        OperacoesBasicas op = new OperacoesBasicas();
        
        System.out.println(op.somar(10, 5));
        System.out.println(op.subtrair(50, 40));
        System.out.println(op.multiplicar(3, 6));
        System.out.println(op.dividir(30, 6));
    }
    
}