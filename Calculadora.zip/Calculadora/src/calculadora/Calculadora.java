package calculadora;
import operacao.OperacoesAvancadas;
import operacao.OperacoesBasicas;

public class Calculadora {

    public static void main(String[] args) {
        
        OperacoesBasicas op = new OperacoesBasicas();
        OperacoesAvancadas opAv = new OperacoesAvancadas();
    
    }
    public String operacao = "";   
    private double num1; 
    private double num2;
    private double resultado;

    public String getOperacao() {
        return operacao;
    }
    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }
    public double getNum1() {
        return num1;
    }
    public void setNum1(double num1) {
        this.num1 = num1;
    }
    public double getNum2() {
        return num2;
    }
    public void setNum2(double num2) {
        this.num2 = num2;
    }
    public double getResultado() {
        return resultado;
    }
    public void setResultado(double resultado) {
        this.resultado = resultado;
    }

    public Calculadora() {
     if(operacao == "+"){
        double num1 = 0;
        double num2 = 0;
        double resultado  = num1 + num2;
     }
    if(operacao == "-"){
        double num1 = 0, num2 = 0;
        double resultado = num1 - num2;
    }
    if(operacao == "*"){
        double num1 = 0;
        double num2  = 0;
        double resultado = num1 * num2;
    }
    if(operacao == "/"){
        double num1 = 0;
        double num2  = 0;
        double resultado = num1 / num2;
    }
    if(operacao == "^"){
        double a = 0;
        double b = 0;
        double resultado  = Math.pow(a, b);
    }
    }
}