package calculadora;

import java.util.Scanner;
import operacao.OperacoesBasicas;

public class Calculadora {

    public static void main(String[] args) {
        
        OperacoesBasicas op = new OperacoesBasicas();
        
        Scanner leia = new Scanner(System.in);
        System.out.println("Digite o pirmeiro número: ");
        double num1 = leia.nextInt();
        
        System.out.println("Digite o segundo número: ");
        double num2 = leia.nextInt();
        
        System.out.println("Qual operação que voce deseja? soma, subtração, "
                + "divisão ou multiplicação");
        String operacao = leia.next();
        double resultado = 0;
        
        if(operacao.equals("soma")){
            System.out.println("Você escolheu soma");
            resultado = op.somar(num1, num2);
        }else if(operacao.equals("subtrair")){
            System.out.println("Você escolheu subtrair");
            resultado = op.subtrair(num1, num2);
        }else if(operacao.equals("multiplicar")){
            System.out.println("Você escolheu multiplicar");
            resultado = op.multiplicar(num1, num2);
        }else if(operacao.equals("dividir")){
            System.out.println("Você escolheu dividir");
            resultado = op.dividir(num1, num2);
        }
        System.out.println(resultado);
    }
    
}