package operacao;

public class OperacoesBasicas {
       
    public double somar(double a, double b){
        double resultado = a + b;
        return resultado;
    }    
    public double subtrair(double a, double b){
        double resultado = a - b;
        return resultado;
    } 
      public double multiplicar(double a, double b){
        double resultado = a * b;
        return resultado;
    }
       public double dividir(double a, double b){
        double resultado = a / b;
        return resultado;
    }  
}