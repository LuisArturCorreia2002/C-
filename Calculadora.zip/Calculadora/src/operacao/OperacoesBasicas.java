package operacao;

public class OperacoesBasicas {
       
    public double somar(double num1, double num2){
        double resultado = num1 + num2;
        return resultado;
    }    
    public double subtrair(double num1, double num2){
        double resultado = num1 - num2;
        return resultado;
    } 
      public double multiplicar(double num1, double num2){
        double resultado = num1 * num2;
        return resultado;
    }
       public double dividir(double num1, double num2){
        double resultado = num1 / num2;
        return resultado;
    }  
}