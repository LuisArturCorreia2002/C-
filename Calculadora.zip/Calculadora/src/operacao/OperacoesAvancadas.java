package operacao;
public class OperacoesAvancadas {
    
    public double Raiz(double a, double b){
        double resultado = Math.sqrt(a);
        return resultado;
    }
    public double potencia(double a, double b){
        double resultado = Math.pow(a, b);
        return resultado;
    }
}