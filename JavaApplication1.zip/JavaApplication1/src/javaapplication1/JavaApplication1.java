package javaapplication1;

public class JavaApplication1 {

    public static void main(String[] args) {
       
        /*Declarar Varíaveis*/
        double base = 3;
        double expoente = 3;
        double resultado = Math.pow(base,expoente);
        System.out.println(resultado);
       
        /*Calcula Raiz*/
        double raiz = Math.sqrt(4);
        System.out.println(raiz);

        /*Calula o número pi*/
        double pi = Math.PI;
        System.out.println(pi);
        
        
        double num1 = 10;
        double num2 = 50;
        
        /*Mostra o maior número*/
        System.out.println(Math.min(num1,num2));
        /*Mostra o menor número*/
        System.out.println(Math.max(num1, num2));
        
        /*Aredondamento para o mais próximo*/
        double numero = 7.7;
        System.out.println(Math.round(numero));
        
        /*Torná-o positivo*/
        numero = -8;
        System.out.println(Math.abs(numero));
        
        /*Arredondamento para cima*/
        numero = 9.4;
        System.out.println(Math.ceil(numero));
    }
}
