package modelo;
public class Calculadora {
     private float value, keep;
    private int toDo;
 
    void CalculatorEngine(){
        value = keep = 0;
    }
 
    void Operation(int op, String tela){
        keep = Float.parseFloat(tela);
        toDo = op;
        System.out.println(keep + "|" + toDo);
    }
    float Display(String tela){
        value = Float.parseFloat(tela);
        System.out.println(value + "|" + toDo);
        switch(toDo){
            case 0: 
                System.out.println(keep + "|" + value);
                return keep+value;
            case 1: 
                System.out.println(keep + "|" + value);
                return keep-value;
            case 2: 
                System.out.println(keep + "|" + value);
                return keep*value;
            case 3:
                System.out.println(keep + "|" + value);
                return keep/value;
            case 4:
                System.out.println(keep + "|" + value);
                return (float) Math.pow(keep, value);
            case 5: 
                float resultado = (float) Math.sqrt(value);
                System.out.println(resultado);
                return (float) Math.sqrt(value);
        }
        return 0;
    }

    private float Mathsqrt(float keep) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
