# Calculadora

![alt text](https://github.com/PassaUmDollar/Calculadora/blob/master/Visual/app.png?raw=true)
